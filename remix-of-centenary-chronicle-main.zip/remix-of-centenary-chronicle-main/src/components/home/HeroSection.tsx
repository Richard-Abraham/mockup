import { ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export function HeroSection() {
  const scrollToContent = () => {
    const nextSection = document.getElementById('alliance-difference');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0 bg-foreground" />
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1541339907198-e08756dedf3f?q=80&w=1920&auto=format&fit=crop')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'grayscale(100%) contrast(1.2)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-hero" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-5 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-primary/20 backdrop-blur-sm border border-primary/30 rounded-full px-4 py-2 mb-6 animate-fade-up">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="font-body text-sm text-background/90 tracking-wider">ONCE ALLIANCE, ALWAYS ALLIANCE</span>
          </div>

          {/* Main Title */}
          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-background mb-5 animate-fade-up delay-100 font-semibold leading-tight">
            A Century of Character.
            <br />
            <span className="text-primary">A Brotherhood for Life.</span>
            <br />
            <span className="text-background/90">A Future Worth Building.</span>
          </h1>

          {/* Subtitle */}
          <p className="font-body text-base md:text-lg text-background/80 font-light mb-6 animate-fade-up delay-200 max-w-3xl mx-auto">
            For many of us, Alliance was never just a school. It was the place where our backs straightened, our thinking sharpened, and our sense of right and wrong was permanently calibrated.
          </p>

          <p className="font-body text-sm md:text-base text-background/70 mb-4 animate-fade-up delay-300 max-w-2xl mx-auto">
            This centenary website exists because 100 years later, that feeling hasn't faded. It still matters that standards are high. It still matters that discipline is lived, not explained. It still matters that young men leave these gates knowing they owe the world something.
          </p>

          <p className="font-body text-sm md:text-base text-background/80 font-medium mb-8 animate-fade-up delay-400 max-w-2xl mx-auto">
            Alliance High School at 100 is not a nostalgia project. It is a moment of reckoning, pride, gratitude—and responsibility.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up delay-500">
            <Button
              variant="default"
              size="lg"
              asChild
            >
              <Link to="/about">
                Join the Centenary Journey
                <ChevronDown className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={scrollToContent}
              className="border-background/30 text-background hover:bg-background/10"
            >
              Explore 100 Years of Alliance
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToContent}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce-slow"
        aria-label="Scroll to content"
      >
        <ChevronDown className="w-8 h-8 text-primary" />
      </button>
    </section>
  );
}
